package com.example.Survey.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveyManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveyManagementApplication.class, args);
	}

}
