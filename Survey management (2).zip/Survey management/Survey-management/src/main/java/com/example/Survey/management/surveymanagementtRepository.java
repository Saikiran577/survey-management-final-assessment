package com.example.Survey.management;

import org.springframework.data.jpa.repository.JpaRepository;

public interface surveymanagementtRepository extends JpaRepository<surveymanagent, Long> {

}