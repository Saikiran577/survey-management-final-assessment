package com.example.Survey.management;

import java.util.List;

public class surveymanagemntRepository {
    public void save(mismanagement product) {
    }

    public List<mismanagement> findAll() {
        return null;
    }

    public List<Object> findById(long id) {
        return null;
    }

    public void deleteById(long id) {
    }
}
